// Selectors
const cartItemsContainer = document.getElementById("cart-items");
const cartTotalElement = document.getElementById("cart-total");

// Retrieve cart from localStorage or initialize empty array
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Function to add item to cart
function addToCart(id, name, price) {
  const existingItem = cart.find((item) => item.id === id);
  if (existingItem) {
    existingItem.quantity++;
  } else {
    cart.push({ id, name, price, quantity: 1 });
  }
  updateCart();
}

// Function to remove item from cart
function removeFromCart(id) {
  cart = cart.filter((item) => item.id !== id);
  updateCart();
}

// Function to render cart items
function renderCartItems() {
  cartItemsContainer.innerHTML = ""; // Clear existing items
  cart.forEach((item) => {
    const row = document.createElement("div");
    row.className = "cart-item";
    row.innerHTML = `
      <span>${item.name}</span>
      <span>Quantity: ${item.quantity}</span>
      <span>$${(item.price * item.quantity).toFixed(2)}</span>
      <button onclick="removeFromCart('${item.id}')">Remove</button>
    `;
    cartItemsContainer.appendChild(row);
  });
}

// Function to calculate and display the total cart price
function calculateCartTotal() {
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  cartTotalElement.innerText = `Total: $${total.toFixed(2)}`;
}

// Function to update cart display and save to localStorage
function updateCart() {
  renderCartItems();
  calculateCartTotal();
  localStorage.setItem("cart", JSON.stringify(cart));
}

// Load cart on page load
document.addEventListener("DOMContentLoaded", () => {
  updateCart();
});

// Event listener for Add to Cart buttons
document.querySelectorAll(".cart-btn").forEach((button) => {
  button.addEventListener("click", (event) => {
    const foodCard = event.target.closest(".food-card");
    const id = foodCard.getAttribute("data-id");
    const name = foodCard.querySelector("h3").innerText;
    const price = parseFloat(
      foodCard.querySelector("p").innerText.replace("Price: $", "")
    );
    addToCart(id, name, price);
  });
});

function updateCartInLocalStorage() {
  localStorage.setItem("cart", JSON.stringify(cart));
}

 // JavaScript function to filter categories
function filterCategory(category) {
  // Get all food cards
  const foodCards = document.querySelectorAll(".food-card");

  // Loop through each card
  foodCards.forEach((card) => {
    if (category === "all" || card.classList.contains(category)) {
      card.style.display = "block"; // Show items in selected category
    } else {
      card.style.display = "none"; // Hide items not in selected category
    }
  });

  // Update active class on category buttons
  const buttons = document.querySelectorAll(".category-button");
  buttons.forEach((btn) => btn.classList.remove("active"));

  // Select the active button using a valid query selector
  const activeButton = document.querySelector(
    `.category-button[onclick="filterCategory('${category}')"]`
  );
  if (activeButton) {
    activeButton.classList.add("active");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  filterCategory("all"); // Default to 'all'
});

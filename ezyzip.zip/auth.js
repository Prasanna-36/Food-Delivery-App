// auth.js
const express = require("express");
const fs = require("fs");
const app = express();
const PORT = 3000;

app.use(express.json());

// Path to the JSON file
const usersFile = "users.json";

// Load users from JSON
function loadUsers() {
  try {
    const data = fs.readFileSync(usersFile, "utf8");
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
}

// Save users to JSON
function saveUsers(users) {
  fs.writeFileSync(usersFile, JSON.stringify(users, null, 2), "utf8");
}

// Registration endpoint
app.post("/register", (req, res) => {
  const { username, password } = req.body;
  const users = loadUsers();

  // Check if username already exists
  if (users.find((user) => user.username === username)) {
    return res.status(400).json({ message: "Username already exists" });
  }

  // Save new user
  users.push({ username, password });
  saveUsers(users);
  res.status(201).json({ message: "Registration successful" });
});

// Login endpoint
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const users = loadUsers();

  // Validate user credentials
  const user = users.find(
    (user) => user.username === username && user.password === password
  );
  if (user) {
    res.status(200).json({ message: "Login successful" });
  } else {
    res.status(401).json({ message: "Invalid credentials" });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = 3000;

// Middleware to parse JSON data from requests
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // Handles form data from HTML

// Define the path to the users.json file
const usersFilePath = path.join(__dirname, "data", "users.json");

// Middleware to load users data or initialize as an empty array if the file doesn't exist
const loadUsers = () => {
  try {
    if (fs.existsSync(usersFilePath)) {
      const fileContent = fs.readFileSync(usersFilePath, "utf-8");
      return fileContent ? JSON.parse(fileContent) : [];
    } else {
      return [];
    }
  } catch (error) {
    console.error("Error loading users file:", error);
    return [];
  }
};

// Function to save users data to the JSON file
const saveUsers = (users) => {
  try {
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2), "utf-8");
  } catch (error) {
    console.error("Error saving users file:", error);
  }
};

// Serve static files from the "public" folder
app.use(express.static(path.join(__dirname, "public")));

// Route for Login Page
app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "login.html"));
});

// Route for Register Page
app.get("/register", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "register.html"));
});

// Route for handling registration
app.post("/register", (req, res) => {
  const { username, email, password } = req.body;

  // Load current users data
  const users = loadUsers();
  console.log("Current Users:", users); // Debug: List all users before adding a new one

  // Check if the username already exists
  const userExists = users.some((user) => user.username === username);

  if (userExists) {
    console.log("Attempted Registration - User already exists:", username);
    return res.status(400).json({ message: "User already exists" });
  }

  // Add new user and save back to the JSON file
  users.push({ username, email, password });
  saveUsers(users); // Save updated users list to file

  console.log("User registered successfully:", username); // Confirm registration success

  // Redirect to login page after successful registration
  res.redirect("/login");
});

// Route for handling login (optional - for later testing)
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const users = loadUsers();

  // Check credentials
  const user = users.find(
    (user) => user.username === username && user.password === password
  );
  if (user) {
    res.redirect("/main.html");
  } else {
    res.status(401).json({ error: "Invalid credentials" });
  }
});

const dataPath = path.join(__dirname, "cartData.json"); // Store cart data here

// Load existing cart data
function loadCartData() {
  try {
    const data = fs.readFileSync(dataPath);
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
}

// Save cart data
function saveCartData(cartData) {
  fs.writeFileSync(dataPath, JSON.stringify(cartData));
}

// Endpoint to add item to cart
app.post("/add-to-cart", (req, res) => {
  const { item } = req.body;
  const cartData = loadCartData();

  const existingItem = cartData.find((cartItem) => cartItem.name === item.name);
  if (existingItem) {
    existingItem.quantity += item.quantity;
  } else {
    cartData.push(item);
  }
  saveCartData(cartData);

  res.send({ success: true, cartData });
});

// Endpoint to update item quantity
app.put("/update-cart", (req, res) => {
  const { itemName, quantity } = req.body;
  const cartData = loadCartData();

  const item = cartData.find((cartItem) => cartItem.name === itemName);
  if (item) {
    item.quantity = quantity;
  }

  saveCartData(cartData);
  res.send({ success: true, cartData });
});

// Endpoint to retrieve cart data
app.get("/get-cart", (req, res) => {
  const cartData = loadCartData();
  res.send({ cartData });
});


// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
